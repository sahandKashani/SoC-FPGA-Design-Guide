#include <assert.h>
#include <errno.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>

#include "hps_linux.h"
#include "hwlib.h"
#include "socal/hps.h"
#include "socal/socal.h"
#include "../hps_soc_system.h"

void open_physical_memory_device() {
    // We need to access the system's physical memory so we can map it to user
    // space. We will use the /dev/mem file to do this. /dev/mem is a character
    // device file that is an image of the main memory of the computer. Byte
    // addresses in /dev/mem are interpreted as physical memory addresses.
    // Remember that you need to execute this program as ROOT in order to have
    // access to /dev/mem.

    fd_dev_mem = open("/dev/mem", O_RDWR | O_SYNC);
    if(fd_dev_mem  == -1) {
        printf("ERROR: could not open \"/dev/mem\".\n");
        printf("    errno = %s\n", strerror(errno));
        exit(EXIT_FAILURE);
    }
}

void close_physical_memory_device() {
    close(fd_dev_mem);
}

void mmap_fpga_peripherals() {
    // Use mmap() to map the address space related to the fpga adder into user
    // space so we can interact with them.

    // The fpga adder is connected to the h2f_lw_axi_master, so its base
    // address is calculated from that of the h2f_lw_axi_master.

    // IMPORTANT: If you try to only mmap the fpga adder, it is possible for the
    // operation to fail, and you will get "Invalid argument" as errno. The
    // mmap() manual page says that you can only map a file from an offset which
    // is a multiple of the system's page size.

    // In our specific case, our fpga adder is located at address 0xFF200000,
    // which is a multiple of the page size, however this is due to luck because
    // the fpga adder is the only peripheral connected to the h2f_lw_axi_master.
    // The typical page size in Linux is 0x1000 bytes.

    // So, generally speaking, you will have to mmap() the closest address which
    // is a multiple of your page size and access your peripheral by a specific
    // offset from the mapped address.

    h2f_lw_axi_master = mmap(NULL, h2f_lw_axi_master_span, PROT_READ | PROT_WRITE, MAP_SHARED, fd_dev_mem, h2f_lw_axi_master_ofst);
    if (h2f_lw_axi_master == MAP_FAILED) {
        printf("Error: h2f_lw_axi_master mmap() failed.\n");
        printf("    errno = %s\n", strerror(errno));
        close(fd_dev_mem);
        exit(EXIT_FAILURE);
    }

    fpga_adder = h2f_lw_axi_master + AVS_ADDER_0_BASE;
}

void munmap_fpga_peripherals() {
    if (munmap(h2f_lw_axi_master, h2f_lw_axi_master_span) != 0) {
        printf("Error: h2f_lw_axi_master munmap() failed\n");
        printf("    errno = %s\n", strerror(errno));
        close(fd_dev_mem);
        exit(EXIT_FAILURE);
    }

    h2f_lw_axi_master = NULL;
    fpga_adder        = NULL;
}

int main() {
    printf("DE0-Nano-SoC linux demo\n");

    open_physical_memory_device();
    mmap_fpga_peripherals();

    uint32_t operand_a = 1;
    uint32_t operand_b = 2;
    uint32_t result = 0;

    // Write operand A to register 0.
    alt_write_word(fpga_adder + (0 * 4), operand_a);

    // Write operand B to register 1.
    alt_write_word(fpga_adder + (1 * 4), operand_b);

    // Read result from register 2.
    result = alt_read_word(fpga_adder + (2 * 4));

    printf("Operand A = %d\n", operand_a);
    printf("Operand B = %d\n", operand_b);
    printf("Result    = %d\n", result);

    munmap_fpga_peripherals();
    close_physical_memory_device();

    return 0;
}
