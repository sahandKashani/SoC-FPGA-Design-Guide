#ifndef HPS_LINUX_H_
#define HPS_LINUX_H_

#include <stdbool.h>
#include <stdint.h>

#include "socal/hps.h"
#include "../hps_soc_system.h"

// physical memory file descriptor
int fd_dev_mem = 0;

void   *h2f_lw_axi_master     = NULL;
size_t h2f_lw_axi_master_span = ALT_LWFPGASLVS_UB_ADDR - ALT_LWFPGASLVS_LB_ADDR + 1;
size_t h2f_lw_axi_master_ofst = ALT_LWFPGASLVS_OFST;

void *fpga_adder = NULL;

void open_physical_memory_device();
void close_physical_memory_device();
void mmap_fpga_peripherals();
void munmap_fpga_peripherals();

#endif
